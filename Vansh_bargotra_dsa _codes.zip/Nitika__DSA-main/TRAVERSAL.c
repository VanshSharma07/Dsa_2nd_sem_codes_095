//C program to Implement a List using Array and develop function to perform Traversal operation
#include <stdio.h>
void main() {
int Arr[5] = {18, 30, 15, 70, 12};
int i;
printf("Elements of the array are:\n");
for(i = 0; i<5; i++) {
printf("Arr[%d] = %d,  ", i, Arr[i]);
}
}
